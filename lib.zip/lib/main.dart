import 'dart:js';
import 'package:flutter/material.dart';
import 'package:project/pages/authentification.page.dart';
import 'package:project/pages/contact.page.dart';
import 'package:project/pages/gallerie.page.dart';
import 'package:project/pages/home.page.dart';
import 'package:project/pages/inscription.page.dart';
import 'package:project/pages/meteo.page.dart';
import 'package:project/pages/parametres.page.dart';
import 'package:project/pages/pays.page.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(MyApp());


class MyApp extends StatelessWidget {
final routes={
  '/parametres':(context)=>ParametresPage(),
  '/contact':(context)=>ContactPage(),
  '/pays':(context)=>PaysPage(),
  '/gallerie':(context)=>GalleriePage(),
  '/meteo':(context)=>MeteoPage(),
  '/home':(context)=>HomePage(),
  '/inscription':(context)=>InscriptionPage(),
  '/authentification':(contex)=>AuthentificationPage(),
};
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: SharedPreferences.getInstance(),
      builder:
      (BuildContext context,AsyncSnapshot<SharedPreferences>prefs){
        var x=prefs.data;
        if(prefs.hasData){
          bool conn=x?.getBool('connecte')?? false;
          if(conn)
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            home: HomePage(),
            routes:routes,
          );
        }
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          home: AuthentificationPage(),
          routes:routes,
        );
      }
    );
  }
}

